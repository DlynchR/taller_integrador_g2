// ============================================================
// wifi_manager.cpp — manejo de conexión WiFi
// ============================================================
#include "wifi_manager.h"
#include "config.h"
#include <WiFi.h>
#include <esp_task_wdt.h>

static WifiState _state          = WifiState::DISCONNECTED;
static uint32_t  _last_attempt   = 0;
static uint8_t   _retry_count    = 0;

static const uint8_t  MAX_RETRIES       = 5;
static const uint32_t RETRY_INTERVAL_MS = 30000;

bool wifi_connect() {
    Serial.printf("[WiFi] Conectando a %s ...\n", WIFI_SSID);
    _state = WifiState::CONNECTING;

    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(false);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    uint32_t start = millis();
    while (WiFi.status() != WL_CONNECTED) {
        if (millis() - start >= WIFI_TIMEOUT_MS) {
            Serial.println("[WiFi] Timeout — sin conexión");
            _state = WifiState::FAILED;
            _retry_count++;
            return false;
        }
        esp_task_wdt_reset();
        delay(500);
        Serial.print(".");
    }

    _state       = WifiState::CONNECTED;
    _retry_count = 0;
    Serial.printf("\n[WiFi] Conectado. IP: %s\n", WiFi.localIP().toString().c_str());
    return true;
}

bool wifi_is_connected() {
    return WiFi.status() == WL_CONNECTED;
}

void wifi_loop() {
    if (WiFi.status() == WL_CONNECTED) {
        _state = WifiState::CONNECTED;
        return;
    }
    _state = WifiState::DISCONNECTED;
    if (millis() - _last_attempt < RETRY_INTERVAL_MS) return;
    _last_attempt = millis();
    if (_retry_count >= MAX_RETRIES) {
        Serial.println("[WiFi] Máximo de reintentos alcanzado");
        _state = WifiState::FAILED;
        return;
    }
    Serial.printf("[WiFi] Reintentando conexión (%d/%d)...\n", _retry_count + 1, MAX_RETRIES);
    wifi_connect();
}

WifiState wifi_get_state() { return _state; }

String wifi_get_ip() {
    if (!wifi_is_connected()) return "0.0.0.0";
    return WiFi.localIP().toString();
}