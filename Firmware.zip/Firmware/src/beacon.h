// ============================================================
// beacon.h — construcción y transmisión del beacon de posición
// Estado S6 de la FSM
// ============================================================
#pragma once

#include <Arduino.h>

// Inicializa el timer del beacon
void   beacon_init();

// Retorna true si es momento de transmitir el beacon
// (basado en BEACON_INTERVAL de config.h)
bool   beacon_is_due();

// Construye y transmite el frame APRS de posición por LoRa
// Retorna true si el TX fue exitoso
bool   beacon_send();

// Retorna el frame APRS del último beacon como String
// (útil para mostrarlo en el OLED o en serial)
String beacon_get_last_frame();